<template>
  <div class="dh_layout_form" v-show="formType !== ''">
    <div class="scroll_wrap">
      <PageHeader
        :title="title"
        @back="hidden"
      />
      <DhLayoutPageItem class="form_row" v-for="(formOpt, formIndex) in formOpts" :key="formIndex">
        <header class="form_row_head">{{formOpt.title}}</header>
        <DhConfigForm :ref="formIndex" class="config_form" :opts="formOpt.opts" />
      </DhLayoutPageItem>
      <slot name="expand"></slot>
    </div>
    <footer class="handle_wrap">
      <Button @click="hidden">取消</Button>
      <Button type="primary" @click="saveHandle" :loading="loading">保存</Button>
    </footer>
  </div>
</template>
<script>
import DhLayoutPageItem from '../../layout-page/src/layout-page-item'
import DhConfigForm from '../../config-form'
import { PageHeader, Input, Button } from 'ant-design-vue'
export default {
  name: 'DhLayoutForm',
  components: {
    PageHeader,
    DhLayoutPageItem,
    DhConfigForm,
    Button
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    formOpts: {
      type: Object,
      default: () => ({})
    },
    submit: {
      type: Function,
      default: () => {}
    }
  },
  data() {
    return {
      loading: false,
      currentHistoryLength: this.getParentHistoryLength()
    }
  },
  computed: {
    formType: { // edit：编辑状态、detail：详情状态
      get() {
        return this.$route.query.formType || ''
      },
      set(v) {
        this.$router.push({
          path: this.$route.fullPath,
          query: {
            formType: v || ''
          }
        })
      }
    },
    isShow() {
      return !!this.formType
    }
  },
  methods: {
    async saveHandle() {
      const self = this
      let form = {}
      let successLength = 0
      this.loading = true
      await Object.keys(self.formOpts).forEach(async (formIndex) => {
        const { valid, formData } = await self.$refs[formIndex][0].validate()
        if (valid) {
          successLength = successLength + 1
          form[formIndex] = formData
        }
      })
      if (successLength === Object.keys(self.formOpts).length) { // 所有表单都校验成功
        const isSuccess = await this.submit(form)
        if (isSuccess) { // 成功
          this.hidden()
        }
      }
      this.loading = false
    },
    show(formType) {
      this.$nextTick(() => {
        this.updateFormFields()
        this.formType = formType
      })
    },
    hidden() { // 根据记录列表的指针位置回退页面到列表页并清空表单数据
      this.$router.go(this.currentHistoryLength - history.length < 0 ? this.currentHistoryLength - history.length : -1)
    },
    resetFormFields() {
      const self = this
      Object.keys(self.formOpts).forEach(formIndex => {
        self.$refs[formIndex][0].resetFields()
      })
    },
    updateFormFields() {
      const self = this
      Object.keys(self.formOpts).forEach(formIndex => {
        self.$refs[formIndex][0].updateFields(false)
      })
    },
    getParentHistoryLength() { // 若在表单页刷新则取前一页的位置
      return this.formType ? history.length - 2 : history.length
    }
  }
}
</script>
<style lang="scss">
.dh_layout_form {
  position: relative;
  display: flex;
  flex-grow: 1;
  flex-direction: column;
  text-align: left;
  .scroll_wrap {
    flex-grow: 1;
    padding-bottom: 8px;
    .ant-page-header {
      padding: 8px 16px;
    }
    .form_row {
      background: #fff;
      .form_row_head {
        margin: -16px -16px 0;
        padding: 16px;
        border-bottom: 1px solid #d9d9d9;
        font-weight: 500;
        font-size: 16px;
        line-height: 24px;
        text-align: left;
        color: #000;
      }
      .config_form {
        padding: 16px 0;
      }
    }
  }
  .handle_wrap {
    position: sticky;
    z-index: 10;
    right: 0;
    bottom: -8px;
    margin: 0 -8px -8px;
    padding: 12px 16px;
    background-color: #fff;
    border-top: 1px solid #d9d9d9;
    text-align: right;
    .ant-btn {
      margin-left: 8px;
    }
  }
}
</style>