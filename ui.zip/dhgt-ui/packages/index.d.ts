import Vue from 'vue';

export declare const index: () => void
export function install(vue: typeof Vue): void;