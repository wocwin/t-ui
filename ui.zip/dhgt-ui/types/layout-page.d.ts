import { ElementUIComponent } from './component'

/** Layoutpage Component */
export declare class Layoutpage extends ElementUIComponent {}
