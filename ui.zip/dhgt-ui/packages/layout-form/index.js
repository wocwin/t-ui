import DhLayoutForm from './src';

/* istanbul ignore next */
DhLayoutForm.install = function(Vue) {
  Vue.component(DhLayoutForm.name, DhLayoutForm);
};

export default DhLayoutForm;
