<template>
  <div class="t-layout-demo">
    <t-layout sectionTitle="布局组件">
      <div class="content-main t-margin20">布局组件</div>
    </t-layout>
  </div>
</template>

<script>
export default {
}
</script>
