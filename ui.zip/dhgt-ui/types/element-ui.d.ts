import Vue from 'vue'
import { ElementUIComponent } from './component'

import { Layoutpage } from './layout-page'


/** The version of element-ui */
export const version: string

/**
 * Install all element-ui components into Vue.
 * Please do not invoke this method directly.
 * Call `Vue.use(ElementUI)` to install.
 */
export function install (vue: typeof Vue, options: InstallationOptions): void

/** ElementUI component common definition */
export type Component = ElementUIComponent


/** Layoutpage Component */
export class Layoutpage extends Layoutpage {}