require('../../modules/es6.function.name');
