require('../../modules/web.dom.iterable');
module.exports = require('../../modules/_core').Array.values;
