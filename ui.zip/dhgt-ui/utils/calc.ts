import NP, { round } from 'number-precision'

function formula(expression: string): number | string {
  if (expression.match(/[+\-*/]/g) === null) { // 无运算符，返回原值
    console.warn('calc：无运算符')
    return expression
  } else if (expression.replace(/\x20/g, '').match(/[^\d\.+\-*/()]/g) !== null) { // 存在数字、运算符外的其他非法字符
    console.warn('calc：存在数字、运算符外的其他非法字符')
    return expression
  }
  expression = expression.replace(/\x20/g, '')
  // 调用运算库进行两个操作数的运算
  function getResult(str: string) {
    str = str.replace(/--/g, '+').replace(/(\+-)|(-\+)/g, '-') // 减号特殊情况处理
    const operators = str.match(/(?<=\d)[-+*/]/g) // 获取运算符
    const nums = str.match(/(((?<=[*/+-])-)|^-)?[\d\.]+/g) // 获取需要计算的数，包含负数的情况
    if (operators !== null && nums !== null && operators[0]) {
      switch (operators[0]) {
        case '-':
          return NP.minus(nums[0], nums[1])
        case '+':
          return NP.plus(nums[0], nums[1])
        case '/':
          return NP.divide(nums[0], nums[1])
        case '*':
          return NP.times(nums[0], nums[1])
        default:
          console.warn('calc：不支持的运算符' + operators[0])
          return ''
      }
    }
    return Number(str)
  }
  // 如果没有括号、且仅剩一次运算，则直接返回运算结果
  const operators = expression.match(/(?<=\d)[-+*/]/g)
  if (operators === null) { // 无运算符
    return Number(expression)
  } else if (expression.match(/\(|\)/g) === null && operators !== null && operators.length === 1) { // 无括号且仅有一个运算符时
    return getResult(expression)
  } else {
    if (expression.match(/\([^()]*\)/i) !== null) {
      // 括号运算
      expression = expression.replace(/\([^()]*\)/g, (str) => {
        const nums = str.match(/(^-)?[\d\.]+/g)
        if (nums && nums.length >= 2) { // 操作数大于两位才运算
          return formula(str.slice(1, str.length - 1)).toString()
        } else {
          return str.slice(1, str.length - 1)
        }
      })
    } else if (expression.match(/\*|\//g) !== null) {
      // 乘除
      expression = expression.replace(/(\d|\.)+(\*|\/)-?(\d|\.)+/i, (str) => {
        return formula(str).toString()
      })
    } else if (expression.match(/(?<=\d)[-+]/g) !== null) {
      // 加减
      expression = expression.replace(/^-?(\d|\.)+(\+|-)(\d|\.)+/i, (str) => {
        return formula(str).toString()
      })
    }
    return formula(expression)
  }
}
export {
  formula,
  round
}
export default {
  formula,
  round
}
