import DhGrid from './src';

/* istanbul ignore next */
DhGrid.install = function(Vue) {
  Vue.component(DhGrid.name, DhGrid);
};

export default DhGrid;
