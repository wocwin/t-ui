import DhConfigForm from './src';
import DhConfigFormItem from './src/config-form-item.vue'

/* istanbul ignore next */
DhConfigForm.install = function(Vue) {
  Vue.component(DhConfigForm.name, DhConfigForm);
}
export {
  DhConfigFormItem,
  DhConfigForm
}

export default DhConfigForm;
