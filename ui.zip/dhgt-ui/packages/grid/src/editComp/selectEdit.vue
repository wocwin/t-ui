<template>
  <Select class="dh_grid_selectEdit" v-bind="opt.bind" v-on="opt.event">
    <SelectOption v-for="item in sourceData" :key="item[customField.key]" :value="item[customField.key]">{{ item[customField.label] }}</SelectOption>
  </Select>
</template>
<script lang="ts">
import Vue from 'vue'
import { Select } from 'ant-design-vue'
import { Component, Prop } from 'vue-property-decorator'
import { EditConfig } from '../types'
@Component({
  components: {
    Select,
    SelectOption: Select.Option
  }
})
export default class SelectEdit extends Vue {
  // 内容
  @Prop({
    type: [ String, Number ],
    default: null
  }) value!: string | number | null
  // 编辑配置
  @Prop({
    type: Object,
    default: () => ({
      type: 'string'
    })
  }) editConfig!: EditConfig

  get opt() {
    return {
      bind: {
        defaultValue: this.value,
        dropdownClassName: 'gridSelectPopup',
        open: true
      },
      event: {
        change: (v: string | number) => {
          this.$emit('input', v)
        }
      }
    }
  }
  get sourceData() {
    return this.editConfig && this.editConfig.data || []
  }
  get customField() {
    return this.editConfig && this.editConfig.customField || {
      key: 'key',
      label: 'label'
    }
  }
  mounted() {
    this.$nextTick(() => {
      for (let ele of document.getElementsByClassName('gridSelectPopup')) { // 阻止mouseup退出编辑模式
        ele.addEventListener('mousedown', (e: Event) => {
          e.stopPropagation()
        })
      }
    })
  }
}
</script>
<style lang="scss">
.dh_grid_selectEdit {
  display: flex !important;
  align-items: center;
  position: absolute !important;
  z-index: 2;
  top: 4px;
  left: 4px;
  width: calc(100% - 8px) !important;
  min-height: calc(100% - 8px);
  background-color: #fff;
  line-height: 21px;
  .ant-select-selection {
    width: 100%;
    height: auto;
    border: none;
    box-shadow: none !important;
  }
  .ant-select-selection__rendered {
    margin-left: 0;
    line-height: 21px;
  }
}
.gridSelectPopup {
  .ant-select-dropdown-menu {
    padding: 0;
  }
}
</style>