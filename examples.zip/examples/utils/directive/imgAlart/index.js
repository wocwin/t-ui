import imgAlart from './alart'

export default {
  install (Vue) {
    Vue.directive('imgAlart', imgAlart)
  }
}
