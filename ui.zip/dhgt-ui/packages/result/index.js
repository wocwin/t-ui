import DhResult from './src';

/* istanbul ignore next */
DhResult.install = function(Vue) {
  Vue.component(DhResult.name, DhResult);
};

export default DhResult;
