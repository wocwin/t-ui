require('../../modules/es7.math.iaddh');
module.exports = require('../../modules/_core').Math.iaddh;
