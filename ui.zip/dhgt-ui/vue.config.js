const path = require('path')
module.exports = {
  css: {
    extract: process.env.NODE_ENV === 'development' ? false : true
  },
  // 修改 src 目录 为 examples 目录
  pages: {
    index: {
      entry: 'examples/main.ts',
      template: 'public/index.html',
      filename: 'index.html'
    }
  },
  configureWebpack: {
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './examples')
      }
    },
    externals: {
      'ant-design-vue': {
        commonjs: 'ant-design-vue',
        commonjs2: 'ant-design-vue',
        amd: 'ant-design-vue',
        root: 'antd'
      }
    }
  }
}