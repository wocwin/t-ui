require('../../../modules/es7.string.match-all');
module.exports = require('../../../modules/_entry-virtual')('String').matchAll;
