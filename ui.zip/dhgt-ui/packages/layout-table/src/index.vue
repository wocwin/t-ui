<template>
  <div class="layout_table">
    <div class="header_wrap">
      <h3>{{title}}<slot name="title" /></h3>
      <div class="header_right_wrap">
        <slot name="btn" />
      </div>
    </div>
    <slot name="table" />
    <Table v-if="!$slots.table" v-bind="antTableOpt">
    </Table>
    <Pagination v-if="pagination !== null" class="pagination"
      :defaultCurrent="1"
      :pageSize="pagination.pageSize"
      :current="pagination.current"
      @change="(current, pageSize) => $emit('paginationChange', current, pageSize)"
      :total="pagination.total && pagination.total >= pagination.pageSize ? pagination.total : pagination.pageSize">
    </Pagination>
  </div>
</template>
<script>
import { Table, Pagination } from 'ant-design-vue'
// import OptComponent from './OptComponent'
export default {
  name: 'DhLayoutTable',
  components: {
    Table,
    Pagination
    // OptComponent
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    columns: {
      type: Array,
      default: () => ([])
    },
    dataSource: {
      type: Array,
      default: () => ([])
    },
    pagination: {
      type: [ Object, null ],
      default: null
    },
    tableOpt: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    antTableOpt() {
      const { columns, dataSource, tableOpt } = this
      return { rowKey: 'id', size: 'middle', ...tableOpt, columns, dataSource, pagination: false }
    }
  }
}
</script>
<style lang="scss">
.layout_table {
  .header_wrap {
    display: flex;
    align-items: center;
    margin-bottom: 24px;
    h3 {
      flex-grow: 1;
      margin: 0;
      font-size: 20px;
      line-height: 28px;
      text-align: left;
    }
  }
  .ant-btn-link {
    height: 16px;
  }
  .pagination {
    position: relative;
    margin-top: 16px;
    padding: 0;
    text-align: right;
  }
}
</style>