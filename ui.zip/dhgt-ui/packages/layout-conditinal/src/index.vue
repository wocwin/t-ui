<template>
  <FormModel label-width="100px" :form="form" layout="horizontal" class="dh_layout_conditional" :style="{'grid-template-areas': gridAreas, 'grid-template-columns': `repeat(${colLength}, minmax(256px, ${100 / colLength}%))`}">
    <DhConfigFormItem v-for="(opt, i) in cOpts" :key="i" :opt="opt" :value="form[opt.dataIndex]" :style="{gridArea: i}" @change="change" />
    <FormModelItem v-if="Object.keys(cOpts).length > 0" label-width="0" style="grid-area: submit_btn" :class="{'flex_end': cellLength % colLength === 0}">
      <Button type="primary" class="btn_check" @click="checkHandle" :loading="loading">查看</Button>
      <Button v-if="reset" class="btn_reset" @click="resetHandle">重置</Button>
    </FormModelItem>
  </FormModel>
</template>
<script>
import { Button, FormModel } from 'ant-design-vue'
import { DhConfigForm } from '../../config-form'
export default {
  name: 'DhLayoutConditional',
  components: {
    FormModel,
    FormModelItem: FormModel.Item,
    Button,
    DhConfigFormItem: DhConfigForm.DhConfigFormItem
  },
  props: {
    opts: {
      type: Object,
      default: () => ({})
    },
    loading: {
      type: Boolean,
      default: false
    },
    reset: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      form: this.initForm(this.opts)
    }
  },
  watch: {
    opts: {
      handler(opts) {
        this.form = this.initForm(opts, true)
      },
      deep: true
    }
  },
  computed: {
    cOpts() { // 二次封装配置
      return Object.keys(this.opts).reduce((acc, field) => {
        let opt = { ...this.opts[field] }
        opt.dataIndex = field
        acc[field] = opt
        return acc
      }, {})
    },
    colLength() { // 行列数
      const width = window.innerWidth
      let colLength = 4
      if (1280 < width && width < 1440) {
        colLength = 3
      } else if (width < 1280) {
        colLength = 2
      }
      return colLength
    },
    gridAreas() { // grid布局按钮位置
      let template = "'. . . .'"
      let length = 1
      switch (this.colLength) {
        case 3:
          template = "'. . .'"
          break;
        case 2:
          template = "'. .'"
          break;
      }
      let areas = [template]
      Object.keys(this.opts).forEach(key => { // 根据控件描述注定占用多少列及顺序
        let span = 1
        if (this.opts[key].span > 1 || this.opts[key].span <= 2) { // 最多占用2列
          span = this.opts[key].span
        }
        // 计算剩余多少未占用的位置
        let count = 0
        let scrstr = areas[areas.length - 1]
        while(scrstr.indexOf('.') != -1 ) {
          scrstr = scrstr.replace(/\./, '')
          count++
        }
        // 若剩余位置不足以放下下一个控件
        if (count < span) {
          areas.push(template)
        }
        let i = 0
        while(i < span) {
          areas[areas.length - 1] = areas[areas.length - 1].replace(/\./, key)
          i ++
          length ++
        }
      })
      // 若控件正好占满一行时，补充多一列放置btn
      if (areas[areas.length - 1].indexOf('.') === -1) {
          areas.push(template)
      }
      if (this.cellLength % this.colLength === 0) { // 正好占满一行
        areas[areas.length - 1] = areas[areas.length - 1].replace(/\.'$/, "submit_btn'")
      } else {
        areas[areas.length - 1] = areas[areas.length - 1].replace(/\./, "submit_btn")
      }
      return (areas + '').replace(/,/g, '')
    },
    cellLength() { // 占用单元格长度
      let length = 0
      Object.keys(this.opts).forEach(key => {
        let span = this.opts[key].span || 1
        length += span
      })
      return length
    }
  },
  methods: {
    initForm(opts, keepVal = false) { // keepVal 保持当前用户选择的结果
      return Object.keys(opts).reduce((acc, field) => {
        acc[field] = (keepVal && this.form && this.form[field]) || opts[field].defaultVal || null
        return acc
      }, {})
    },
    resetHandle() {
      this.form = this.initForm(this.opts)
      this.$emit('reset', this.form)
      this.checkHandle()
    },
    change(v, dataIndex) {
      this.form[dataIndex] = v
      this.$emit('change', { ...this.form })
    },
    checkHandle() {
      this.$emit('submit', Object.keys(this.form).reduce((acc, field) => {
        if (typeof this.form[field] === 'string') { // 去除前后空格
          this.form[field] = this.form[field].trim()
        }
        acc[field] = this.form[field]
        return acc
      }, {}))
    }
  }
}
</script>
<style lang="scss">
.dh_layout_conditional.ant-form {
  display: grid;
  grid-template-columns: repeat(4, minmax(256px, 25%));
  margin-bottom: -7px;
  text-align: left;
  overflow: hidden;
  .ant-calendar-picker {
    width: 100%!important;
  }
  .flex_end {
    grid-area: submit_btn;
    .ant-form-item-control {
      text-align: right!important;
    }
  }
  .ant-form-item {
    display: flex;
    margin-bottom: 6px;
    .ant-form-item-label {
      min-width: 100px;
      padding-left: 10px;
    }
    .ant-form-item-control-wrapper {
      flex-grow: 1;
      .ant-form-item-control {
        text-align: left;
      }
    }
  }
  .btn_check {
    position: relative;
    top: -1px;
    margin-left: 16px;
  }
  .btn_reset {
    position: relative;
    top: -1px;
    margin-left: 8px;
  }
}
</style>