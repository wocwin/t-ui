require('../../modules/es6.reflect.enumerate');
module.exports = require('../../modules/_core').Reflect.enumerate;
