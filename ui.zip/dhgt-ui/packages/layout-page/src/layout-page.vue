<template>
  <div class="dh_layout_page">
    <slot />
  </div>
</template>
<script>
export default {
  name: 'DhLayoutPage'
}
</script>
<style lang="scss" scoped>
.dh_layout_page {
  display: flex;
  flex-direction: column;
  padding: 8px;
  width: 100%;
  height: 100%;
  overflow: auto;
}
</style>