<template>
  <InputNumber ref="InputNumber" class="dh_grid_inputNumberEdit" v-bind="opt.bind" v-on="opt.event" @mouseup.native.stop />
</template>
<script lang="ts">
import Vue from 'vue'
import moment from 'moment'
import { InputNumber } from 'ant-design-vue'
import { Component, Prop } from 'vue-property-decorator';
@Component({
  components: {
    InputNumber
  }
})
export default class InputNumberEdit extends Vue {
  // 内容
  @Prop({
    type: [ String, Number ],
    default: null
  }) value!: string | number | null
  
  get opt() {
    return {
      bind: {
        value: this.value
      },
      event: {
        blur: (v: Event) => {
          v.target && this.$emit('input', (v.target as any).value)
        }
      }
    }
  }
  mounted() {
    this.$nextTick(() => {
      (this.$refs.InputNumber as any).$refs.inputNumberRef.$refs.inputRef.select()
    })
  }
}
</script>
<style lang="scss">
.dh_grid_inputNumberEdit.ant-input-number {
  display: flex;
  flex-direction: column;
  position: absolute;
  z-index: 2;
  top: 4px;
  left: 4px;
  width: calc(100% - 8px) !important;
  min-height: calc(100% - 8px);
  height: auto !important;
  border: none;
  line-height: 21px;
  .ant-input-number-input-wrap {
    display: flex;
    flex-grow: 1;
    .ant-input-number-input {
      flex-grow: 1;
    }
  }
  &.ant-input-number-focused {
    box-shadow: none;
  }
  .ant-input-number-handler-wrap {
    display: none;
  }
  .ant-input-number-input {
    padding: 0;
    height: auto;
  }
}
</style>