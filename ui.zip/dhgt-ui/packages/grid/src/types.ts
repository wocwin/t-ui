import { VNode } from 'vue/types/umd'
import { CreateElement } from 'vue';

export interface EditConfig {
  type: string,
  format?: string,
  data: [],
  customField: {
    key: string,
    label: string
  }
}
export interface Col {
  dataIndex: string,
  title: (h: CreateElement) => VNode | string,
  width?: string,
  minWidth?: string,
  maxWidth?: string,
  children?: Col[],
  fixed?: string,
  className?: string[],
  colSpan?: number,
  rowSpan?: number,
  editConfig?: EditConfig | null,
  render?: (h: CreateElement, dataIndex: string, rowIndex: number, value: string | number | null ) => VNode
}
export interface CellMousedownBackParams {
  isFixed: boolean,
  dataIndex: string,
  rowIndex: number,
  offsetTop: number,
  offsetLeft: number,
  width: number,
  height: number
}
