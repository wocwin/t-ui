<template>
  <FormModelItem :label="opt.label" :prop="opt.dataIndex" :ref="opt.dataIndex">
    <OptComponent v-bind="opt" :value="value" @change="change"/>
  </FormModelItem>
</template>
<script>
import OptComponent from './OptComponent'
import { FormModel } from 'ant-design-vue'
export default {
  name: 'DhConfigFormItem',
  components: {
    OptComponent,
    FormModelItem: FormModel.Item
  },
  props: {
    opt: {
      type: Object,
      default: () => ({})
    },
    value: {
      type: [String, Number, Array, Object],
      default: null
    }
  },
  methods: {
    change(v, dataIndex) {
      this.$emit('change', v, dataIndex)
    },
  }
}
</script>