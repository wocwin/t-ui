export default {
  methods: {
    addKeyListener() {
      document.documentElement.addEventListener('keydown', this.keyListener)
    },
    removeKeyListener() {
      document.documentElement.removeEventListener('keydown', this.keyListener)
    },
    keyListener(e) {
      console.log(e)
      const { rect } = this
      const cellStatus = this.cellStatus
      switch (e.key) {
        case 'Tab':
          e.preventDefault()
          this.rect = this.getCellInfo(rect.dataIndex, rect.rowIndex, 'r')
          this.$nextTick(() => { // 渲染完成后恢复原来状态
            if (cellStatus === 'edit') {
              this.cell2Edit()
            } else {
              this.cellStatus = cellStatus
            }
          })
          this.$emit('keydown', 'Tab', { dataIndex: rect.dataIndex, rowIndex: rect.rowIndex })
          break;
        case 'Enter':
          e.preventDefault()
          this.rect = this.getCellInfo(rect.dataIndex, rect.rowIndex, 'b')
          this.$nextTick(() => { // 渲染完成后恢复原来状态
            if (cellStatus === 'edit') {
              this.cell2Edit()
            } else {
              this.cellStatus = cellStatus
            }
          })
          this.$emit('keydown', 'Enter', { dataIndex: rect.dataIndex, rowIndex: rect.rowIndex })
          break;
      
        default:
          break;
      }
    }
  }
}