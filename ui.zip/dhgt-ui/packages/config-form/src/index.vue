<template>
  <FormModel ref="form" class="dh_config_form" :model="form" :rules="rules">
    <DhConfigFormItem v-for="(opt, i) in cOpts" :key="i" :opt="opt" :value="form[opt.dataIndex]" :i="i" @change="change" />
  </FormModel>
</template>
<script>
import DhConfigFormItem from './config-form-item.vue'
import { FormModel } from 'ant-design-vue'
export default {
  name: 'DhConfigForm',
  DhConfigFormItem,
  components: {
    DhConfigFormItem,
    FormModel
  },
  props: {
    opts: {
      type: Object,
      default: () => ({})
    },
  },
  data() {
    return {
      form: this.initForm(this.opts)
    }
  },
  computed: {
    cOpts() { // 二次封装配置
      return Object.keys(this.opts).reduce((acc, field) => {
        let opt = { ...this.opts[field] }
        opt.dataIndex = field
        acc[field] = opt
        return acc
      }, {})
    },
    rules() {
      return Object.keys(this.opts).reduce((acc, field) => {
        if (this.opts[field].rules) {
          acc[field] = this.opts[field].rules
        }
        return acc
      }, {})
    }
  },
  methods: {
    initForm(opts, keepVal = false) { // keepVal 是否保持表单已有数据
      return Object.keys(opts).reduce((acc, field) => {
        acc[field] = (keepVal && this.form && this.form[field]) || opts[field].defaultVal || null
        return acc
      }, {})
    },
    updateFields(keepVal = true) {
      this.form = this.initForm(this.opts, keepVal)
    },
    change(v, dataIndex) {
      this.form[dataIndex] = v
      this.$emit('change', { ...this.form })
    },
    validate() {
      return new Promise((resolve, reject) => {
        this.$refs.form.validate(valid => {
          if (valid) {
            resolve({
              valid,
              formData: Object.keys(this.form).reduce((acc, field) => {
              if (typeof this.form[field] === 'string') { // 去除前后空格
                this.form[field] = this.form[field].trim()
              }
              acc[field] = this.form[field]
              return acc
            }, {})
            })
          } else {
            reject({
              valid,
              formData: null
            })
          }
        })
      })
    },
    resetFields() {
      return this.$refs.form.resetFields()
    }
  }
}
</script>
<style lang="scss">
.dh_config_form {
  display: grid;
  grid-gap: 0 16px;
  @media screen and (min-width: 1440px) {
    grid-template-columns: repeat(4, 1fr);
  }
  @media screen and (max-width: 1440px) {
    grid-template-columns: repeat(3, 1fr);
  }
  @media screen and (max-width: 992px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media screen and (max-width: 768px) {
    grid-template-columns: repeat(1, 1fr);
  }
  .ant-select {
    width: 100%;
  }
}
</style>
