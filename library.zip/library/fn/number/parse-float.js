require('../../modules/es6.number.parse-float');
module.exports = require('../../modules/_core').Number.parseFloat;
