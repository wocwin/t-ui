<script lang="ts">
import Vue from 'vue'
import DatePickerEdit from './editComp/datePickerEdit.vue'
import InputEdit from './editComp/inputEdit.vue'
import InputNumberEdit from './editComp/inputNumberEdit.vue'
import SelectEdit from './editComp/selectEdit.vue'
import moment from 'moment'
import { Component, Prop, Watch } from 'vue-property-decorator'
import { Col } from './types'
@Component({
  components: {
    DatePickerEdit,
    InputEdit,
    InputNumberEdit,
    SelectEdit
  }
})
export default class DhGridCell extends Vue {
  // 内容
  @Prop({
    type: [ String, Number ],
    default: null
  }) value!: string | number | null
  // 数据类型
  @Prop({
    type: Object,
    default: () => ({})
  }) col!: Col
  // 左侧冻结列数
  @Prop({
    type: Number,
    default: 0
  }) fixedColumnLeft?: number
  // 右侧冻结列数
  @Prop({
    type: Number,
    default: 0
  }) fixedColumnRight?: number
  // 当前列序号
  @Prop({
    type: Number,
    default: 0
  }) colIndex!: number
  // 当前行序号
  @Prop({
    type: Number,
    default: 0
  }) rowIndex!: number
  // 当前列总数
  @Prop({
    type: Number,
    default: 0
  }) colLength!: number
  // 自定义单元格样式
  @Prop({
    type: Function
  }) cellStyle?: Function
  // 是否编辑过
  @Prop({
    type: Boolean,
    default: false
  }) isChanged!: boolean
  // 单元格状态，readonly 只读、edit 编辑
  @Prop({
    type: String,
    default: 'readonly'
  }) status!: string
  // 单元格选中状态
  @Prop({
    type: Boolean,
    default: false
  }) actived!: boolean

  dateOpen = true
  offsetLeft = -1 // 左侧冻结
  offsetWidth = -1 // 右侧冻结需要用到
  parentOffsetWidth = -1 // 父级宽度
  customStyle: any = {} // 装载用户自定义样式
  clickTimer: any = 0 // 单击事件延时处理双击

  get cellVal() {
    const { editConfig } = this.col
    let val = this.value
    if (editConfig && editConfig.type === 'select') {
      const customField = editConfig.customField || {
        key: 'key',
        label: 'label'
      }
      editConfig.data.some(item => {
        if (item[customField.key] === this.value) {
          val = item[customField.label]
          return true
        }
      })
    }
    return val || val === 0 ? val.toString() : ''
  }
  get fixed() {
    const { fixedColumnLeft, fixedColumnRight, colIndex, colLength } = this
    if (fixedColumnLeft && colIndex + 1 <= fixedColumnLeft) {
      return 'left'
    } else if (fixedColumnRight && colLength - colIndex <= fixedColumnRight) {
      return 'right'
    } else {
      return 'none'
    }
  }
  get fixedBorderL() {
    const { fixedColumnLeft, colIndex } = this
    if (fixedColumnLeft && colIndex + 1 === fixedColumnLeft) {
      return true
    } else {
      return false
    }
  }
  get fixedBorderR() {
    const { fixedColumnRight, colIndex, colLength } = this
    if (fixedColumnRight && colLength - colIndex === fixedColumnRight) {
      return true
    } else {
      return false
    }
  }
  get style() {
    const { minWidth } = this.col
    const { fixed, offsetLeft, offsetWidth, parentOffsetWidth, customStyle } = this
    let style: any = { ...customStyle }
    if (minWidth) {
      style.minWidth = minWidth.replace(/\d+/g, str => {
        return (Number(str)).toString()
      })
    }
    if (fixed !== 'none' && offsetWidth !== -1) {
      style.position = 'sticky'
      style.zIndex = 20
      if (fixed === 'left') {
        style.left = offsetLeft + 'px'
      } else if (fixed === 'right') {
        style.right = parentOffsetWidth - offsetLeft - offsetWidth + 1 + 'px'
      }
    }
    return style
  }
  get editCompName() {
    const { editConfig } = this.col
    if (!editConfig) return ''
    switch (editConfig.type) {
      case 'string':
        return InputEdit
      case 'number':
        return InputNumberEdit
      case 'date':
        return DatePickerEdit
      case 'select':
        return SelectEdit
      default:
        return 'div'
    }
  }
  render(h: Vue.CreateElement) {
    const { fixed, col, rowIndex, value, cellVal, isChanged, colIndex, fixedBorderL, fixedBorderR, selected, dblclick, click, style, status, actived, editCompName, clickTimer } = this
    let children: Vue.VNodeChildren = ''
    if (col.render) {
      children = [col.render(h, col.dataIndex, rowIndex, value)]
    } else if (status === 'edit' && actived) {
      children = [cellVal, h(editCompName, {
        props: {
          value: value,
          editConfig: col.editConfig
        },
        nativeOn: {
          mousedown(e: Event) {
            e.stopPropagation()
          }
        },
        on: {
          input: this.onValueChanged
        }
      })]
    } else {
      children = cellVal
    } 
    return [h('td', {
      class: {
        'dh_grid_cell': true,
        'is-Changed': isChanged,
        'is_edit': status === 'edit' && actived,
        'first_cell': colIndex === 0,
        'fixed_left': fixedBorderL,
        'fixed_right': fixedBorderR
      },
      attrs: {
        'data-fixed': fixed
      },
      on: {
        dblclick: (e: Event) => {
          clearTimeout(clickTimer)
          dblclick()
        },
        click: () => { // 同时响应双击和单击事件，避免重复
          clearTimeout(clickTimer)
          this.clickTimer = setTimeout(click, 200)
        }
      },
      style
    }, children)]
  }
  mounted() {
    this.$nextTick(() => {
      this.getCustomStyle()
      if (this.fixed !== 'none' && (this.$el as HTMLElement) !== null) {
        const $el = this.$el as HTMLElement
        this.offsetLeft = $el.offsetLeft
        this.offsetWidth = $el.offsetWidth
        if ($el.parentElement !== null) {
          this.parentOffsetWidth = $el.parentElement.offsetWidth
        }
      }
    })
  }
  onValueChanged(val: string | number | null) {
    this.$emit('change', val, this.col.dataIndex, this.rowIndex)
  }
  dblclick() {
    this.$emit('dblclick', { colIndex: this.colIndex, rowIndex: this.rowIndex, value: this.value, event: this.$el })
  }
  // 单击单元格，此处主要实现事件通知
  click() {
    this.$emit('click', { dataIndex: this.col.dataIndex, rowIndex: this.rowIndex })
  }
  getCustomStyle() { // 减少初始化渲染等待
    this.customStyle = this.cellStyle ? this.cellStyle(this.col.dataIndex, this.rowIndex, this.value) : {}
  }
}
</script>
<style lang="scss">
@import './index.scss';
@keyframes shaky {
  0% {
    transform: translateX(0);
  }
  25% {
    transform: translateX(-2px);
  }
  50% {
    transform: translateX(0);
  }
  75% {
    transform: translateX(2px);
  }
}
.dh_grid_cell {
  position: relative;
  padding: 4px;
  width: auto;
  height: 29px;
  background-color: #fff;
  // border-top: 1px solid $border-color;
  // border-right: 1px solid $border-color;
  box-shadow: inset -1px -1px 0 0 $border-color;
  text-align: left;
  white-space: pre-line;
  word-break: break-all;
  line-height: 21px;
  // &.fixed_left {
  //   box-shadow: 1px 2px 2px 0 #ccc;
  // }
  &.first_cell::before {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    display: block;
    width: 1px;
    border-left: 1px solid $border-color;
  }
  &.fixed_right::before {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: -1px;
    display: block;
    width: 1px;
    border-left: 1px solid $border-color;
  }
  &.shaky {
    border-right: 0;
    animation: shaky .15s;
    animation-iteration-count: infinite;
  }
  &.is_changed::after {
    content: '';
    position: absolute;
    z-index: 2;
    top: 0;
    right: 0;
    display: inline-block;
    width: 8px;
    height: 8px;
    border: 4px solid;
    border-color: $theme-color $theme-color transparent transparent;
  }
  &.is_edit {
    box-shadow: 0 0 0px 2px #355db4 inset;
  }
}
</style>