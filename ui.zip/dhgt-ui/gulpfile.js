const gulp = require('gulp')
const cp = require('child_process')
const { main } = require('./package.json')

exports.default = () => {
  return gulp.watch('packages/**', { ignoreInitial: false, delay: 500 }, (cb) => {
    console.log('开始构建')
    cp.exec('npm run lib:dev', (err, stdout, stderr) => {
      console.log('转移构建文件')
      console.log(stdout)
      gulp.src('./lib/**')
        .pipe(gulp.dest('../iif-platform-fe/node_modules/dhgt-ui/lib/'))
      console.log('DONE!')
      cb()
    })
  })
}