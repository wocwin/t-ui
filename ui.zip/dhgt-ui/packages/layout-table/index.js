import DhLayoutTable from './src';

/* istanbul ignore next */
DhLayoutTable.install = function(Vue) {
  Vue.component(DhLayoutTable.name, DhLayoutTable);
};

export default DhLayoutTable;
