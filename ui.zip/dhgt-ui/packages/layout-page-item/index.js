import DhgtLayoutPageItem from '../layout-page/src/layout-page-item';

/* istanbul ignore next */
DhgtLayoutPageItem.install = function(Vue) {
  Vue.component(DhgtLayoutPageItem.name, DhgtLayoutPageItem);
};

export default DhgtLayoutPageItem;
