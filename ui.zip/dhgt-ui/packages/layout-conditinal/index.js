import DhLayoutConditional from './src';

/* istanbul ignore next */
DhLayoutConditional.install = function(Vue) {
  Vue.component(DhLayoutConditional.name, DhLayoutConditional);
};

export default DhLayoutConditional;
