<template>
  <div class="dh_grid">
    <div v-if="!hideHeader" class="dh_grid_sticky_head">
      <table ref="tableHead" class="dh_grid_table" border="0" cellspacing="0" cellpadding="0">
        <colgroup>
          <col v-for="(col, key) in columnFields" :key="'col' + key + col.dataIndex" :style="getColStyle(col)" />
        </colgroup>
        <Columns
          :columns="fullColumns"
          :fixedColumnLeft="fixedColumnLeft"
          :fixedColumnRight="fixedColumnRight"
          :col-length="columnFields.length"
        />
        <tbody>
          <tr>
            <td v-for="(col, key) in columnFields" :key="'col' + key + col.dataIndex" :style="getColStyle(col)"></td>
          </tr>
        </tbody>
      </table>
    </div>
    <table ref="tableBody" class="dh_grid_table table" :style="{marginTop: `${headHeight}px`}" border="0" cellspacing="0" cellpadding="0">
      <colgroup>
        <col v-for="(col, key) in columnFields" :key="'col' + key + col.dataIndex" :style="getColStyle(col)" />
      </colgroup>
      <tbody ref="tableBodyWrap">
        <tr v-for="(row, rowIndex) in tableData" :key="row[rowKey]" :class="`row-${rowIndex}`">
          <template v-for="(col, colIndex) in columnFields">
            <Cell v-if="getCellRowSpan(col.dataIndex, rowIndex) !== 0 && getCellColSpan(columnKey[col.dataIndex], rowIndex) !== 0"
              :key="col.dataIndex + row[col.dataIndex] + row[col.dataIndex]"
              :rowspan="getCellRowSpan(col.dataIndex, rowIndex)"
              :colspan="getCellColSpan(columnKey[col.dataIndex], rowIndex)"
              :value="row[col.dataIndex]"
              :is-changed="changedCell[col.dataIndex] && changedCell[col.dataIndex].includes(rowIndex)"
              :status.sync="cellStatus"
              :actived="rect.dataIndex === col.dataIndex && rect.rowIndex === rowIndex"
              @change="dataChanged"
              @click="cellClick"
              @dblclick="cellDblClick"
              @mousedown.native.stop="selectCell({rowIndex: rowIndex, dataIndex: col.dataIndex})"
              @mouseenter.native.self="cellMouseenter"
              @mouseup.native="cellMouseup"
              :cellStyle="cellStyle"
              :row-index="rowIndex"
              :data-index="col.dataIndex"
              :col-index="colIndex"
              :col-length="columnFields.length"
              :fixedColumnLeft="fixedColumnLeft"
              :fixedColumnRight="fixedColumnRight"
              :col="col" />
          </template>
        </tr>
      </tbody>
      <CellRect v-if="cellRectDisplay" v-bind="rect" />
    </table>
    <!-- <div v-if="!selectDisabled && rect.h !== 0 && rect.w !== 0" class="br_point" :style="`top: ${rect.y + rect.h - 6}px; left: ${rect.x + rect.w - 6}px`"></div> -->
    <div ref="sticky_scroll_x" class="sticky_scroll_x"><span class="scroll_cont" :style="{width: `${headWidth}px`}"></span></div>
  </div>
</template>
<script>
import Vue from 'vue'
import Columns from './columns/index.vue'
import Cell from './cell.vue'
import CellRect from './cellRect.vue'
import rowSelectionJs from './rowSelection.js'
import keyListenerJs from './keyListener.js'
export default {
  name: 'DhGrid',
  mixins: [ rowSelectionJs, keyListenerJs ],
  components: {
    Columns,
    Cell,
    CellRect
  },
  props: {
    // 列头描述
    columns: {
      type: Array,
      default: () => []
    },
    // 左冻结列
    fixedColumnLeft: {
      type: Number,
      default: 0
    },
    // 右冻结列
    fixedColumnRight: {
      type: Number,
      default: 0
    },
    // 隐藏表头
    hideHeader: {
      type: Boolean,
      default: false
    },
    // 禁用选中
    selectDisabled: {
      type: Boolean,
      default: false
    },
    // 跨行合并
    rowSpan: {
      type: Object,
      default: () => ({})
    },
    // 跨列合并
    colSpan: {
      type: Object,
      default: () => ({})
    },
    // 行key的取值
    rowKey: {
      type: [ String, Function ],
      default: 'key'
    },
    // 自定义单元格样式
    cellStyle: Function,
    // 单元格是否可编辑
    cellEditDisabled: Function,
    // 多选
    rowSelectionKeys: {
      type: [ Array, null ],
      default: null
    },
    // 禁止选择的行
    disabledRowSelectionKeys: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      tableData: [],
      changedCell: {},
      rect: {
        dataIndex: '',
        rowIndex: -1,
        isFixed: false,
        x: 0,
        y: 0,
        w: 0,
        h: 0,
        wrapW: 0
      },
      isMousedown: false, // 鼠标是否按下
      headHeight: 0,
      headWidth: 0,
      cellStatus: 'readonly' // 单元格状态
    }
  },
  computed: {
    fullColumns() { // 原列描述前合并多选列
      return this.selectionCol.concat(this.columns)
    },
    columnFields() { // 获取column最低层级的字段集
      let columnFields = [].concat(this.selectionCol)
      this.columns.forEach(col => {
        columnFields = columnFields.concat(this.getLastCol(col))
      })
      return columnFields
    },
    colDataIndexFields() { // 获取column最低层级的字段集dataIndex数组
      return this.columnFields.reduce((acc, cur) => {
        acc.push(cur.dataIndex)
        return acc
      }, [])
    },
    columnKey() { // dataIndex对应序号
      let columnKey = {}
      this.columnFields.forEach((col, key) => {
        columnKey[col.dataIndex] = key
      })
      return columnKey
    },
    cellRowSpan() { // 根据配置加入不渲染的单元格描述
      let cellRowSpan = {}
      const { rowSpan } = this
      if (rowSpan) {
        Object.keys(rowSpan).forEach(dataIndex => {
          cellRowSpan[dataIndex] = {}
          let lastIndex = ''
          Object.keys(rowSpan[dataIndex]).forEach(rowIndex => {
            const span = rowSpan[dataIndex][rowIndex]
            if (cellRowSpan[dataIndex][rowIndex] === 0) { // 当前单元格被合并
              // FIXME: 此处暂定为顺序排列，乱序需先排序
              cellRowSpan[dataIndex][lastIndex] = Number(rowIndex) - Number(lastIndex)
            }
            cellRowSpan[dataIndex][rowIndex] = span
            let step = 1
            while (span - step >= 1) {
              cellRowSpan[dataIndex][Number(rowIndex) + step] = 0 // 需要隐藏的行
              step ++
            }
            lastIndex = rowIndex // 记录下当前rowIndex，后面单元格冲突时需要处理
          })
        })
      }
      return cellRowSpan
    },
    cellColSpan() { // 根据配置加入不渲染的单元格描述
      let cellColSpan = {}
      const { colSpan, fixedColumnLeft, fixedColumnRight, columnFields } = this
      if (colSpan) {
        Object.keys(colSpan).forEach(rowIndex => {
          cellColSpan[rowIndex] = {}
          let lastIndexKey = 0
          Object.keys(this.columnKey).forEach(dataIndex => { // 根据列顺序取数，避免冲突，序号越后优先级越高
            const span = colSpan[rowIndex][dataIndex]
            const dataIndexKey = this.columnKey[dataIndex] // 该列序号
            if ((span || span === 0) && (!this.isColFixed(dataIndexKey) || (this.isColFixed(dataIndexKey) && this.isColFixed(dataIndexKey + span - 1)))) { // 非冻结列
              if (cellColSpan[rowIndex][dataIndexKey] === 0) { // 当前单元格被合并
                cellColSpan[rowIndex][lastIndexKey] = dataIndexKey - Number(lastIndexKey)
              }
              cellColSpan[rowIndex][dataIndexKey] = span
              let step = 1
              while (span - step >= 1) {
                cellColSpan[rowIndex][dataIndexKey + step] = 0 // 需要隐藏的行
                step ++
              }
              lastIndexKey = dataIndexKey // 记录下当前dataIndexKey，后面单元格冲突时需要处理
            }
          })
        })
      }
      return cellColSpan
    },
    cellRectDisplay() {
      const { selectDisabled, cellStatus, rect } = this
      if (selectDisabled) {
        return false
      } else if (rect.w === 0 || rect.h === 0) {
        return false
      } else if (cellStatus === 'edit') {
        return false
      }
      return true
    }
  },
  watch: {
    'selectDisabled': function(n) {
      this.setSelectDisabled(n)
    },
    'columns': function() {
      // 更新列头高度
      this.$nextTick(() => {
        this.headHeight = this.$refs.tableHead.scrollHeight
        this.headWidth = this.$refs.tableHead.scrollWidth
      })
    },
    'rect': function(rect) {
      if (rect.rowIndex >= 0) {
        document.documentElement.addEventListener('mousedown', this.gridBlur)
      } else {
        document.documentElement.removeEventListener('mousedown', this.gridBlur)
      }
    }
  },
  mounted() {
    // 初始化禁用
    this.selectDisabled && this.setSelectDisabled(this.selectDisabled)
    this.syncScroll()
  },
  destroyed() {
    document.documentElement.removeEventListener('mousedown', this.gridBlur)
  },
  methods: {
    setData(data) { // 设置数据源
      this.tableData = JSON.parse(JSON.stringify(data))
      this.changedCell = {}
    },
    isColFixed(dataIndexKey) { // 查询当前列是否为冻结列
      const { fixedColumnLeft, fixedColumnRight, columnFields } = this
      if (fixedColumnLeft && dataIndexKey <= fixedColumnLeft - 1) {
        return true
      } else if (fixedColumnRight && columnFields.length - dataIndexKey <= fixedColumnRight) {
        return true
      } else {
        return false
      }
    },
    getCellRowSpan(dataIndex, rowIndex) { // 获取单元格跨行配置
      if (!this.cellRowSpan[dataIndex]) { // 无跨行
        return 1
      } else if (!this.cellRowSpan[dataIndex][rowIndex] && this.cellRowSpan[dataIndex][rowIndex] !== 0) { // 无当前行
        return 1
      } else {
        return this.cellRowSpan[dataIndex][rowIndex]
      }
    },
    getCellColSpan(dataIndexKey, rowIndex) { // 获取单元格跨列配置
      if (!this.cellColSpan[rowIndex]) { // 无跨列
        return 1
      } else if (!this.cellColSpan[rowIndex][dataIndexKey] && this.cellColSpan[rowIndex][dataIndexKey] !== 0) { // 无当前列
        return 1
      } else {
        return this.cellColSpan[rowIndex][dataIndexKey]
      }
    },
    getColStyle(col) { // 获取列样式
      const { width, minWidth, maxWidth } = col
      let style = {}
      if (width) {
        style.width = width
      }
      if (minWidth) {
        style.minWidth = minWidth
      }
      if (maxWidth) {
        style.maxWidth = maxWidth
      }
      return style
    },
    getLastCol(col) { // 取得最后层级的列描述，用于决定渲染内容以哪列为准
      let lastFields = []
      if (col.children && col.children.length > 0) { // 存在子集
        col.children.forEach(cCol => {
          lastFields = lastFields.concat(this.getLastCol(cCol))
        })
      } else {
        lastFields.push(col)
      }
      return lastFields
    },
    getCellInfo(dataIndex, rowIndex, direction = 'c', num = 0) { // 获取单元格属性，direction: r|b|c 支持选择指定单元格的右、下单元格，num用于记录查找次数，避免溢出
      const colIndex = this.colDataIndexFields.indexOf(dataIndex)
      if (direction === 'r' && colIndex < this.colDataIndexFields.length - 1) {
        dataIndex = this.colDataIndexFields[colIndex + 1]
      } else if (direction === 'b' && rowIndex < this.tableData.length - 1) {
        rowIndex = rowIndex + 1
      }
      const rootElements = this.$el.querySelectorAll(`.row-${rowIndex} [data-index=${dataIndex}]`)
      if (dataIndex && rootElements.length === 1) {
        const rootElement = rootElements[0]
        const dataIndex = rootElement.getAttribute('data-index')
        const fixed = rootElement.getAttribute('data-fixed')
        return {
          dataIndex,
          rowIndex,
          isFixed: fixed !== 'none',
          // 若浮动则需要减去滚动的距离
          x: fixed !== 'none' && rootElement.offsetParent ? rootElement.offsetLeft - rootElement.offsetParent.scrollLeft - 1 : rootElement.offsetLeft - 1,
          y: rootElement.offsetTop - 1,
          w: rootElement.offsetWidth,
          h: rootElement.offsetHeight,
          wrapW: this.$refs.tableBodyWrap.offsetWidth
        }
      } else if (num < 30) { // 找不到继续按相同方向继续找，限制尝试30次
        return this.getCellInfo(dataIndex, rowIndex, direction, num + 1)
      } else {
        return this.rect
      }
    },
    syncScroll() { // 同步表头与表格的横向滚动
      if (this.hideHeader) return
      let onScroll = false
      let timer = 0
      this.$nextTick(() => {
        this.headHeight = this.$refs.tableHead.scrollHeight
        this.headWidth = this.$refs.tableHead.scrollWidth
        // 同步body与head的横向滚动
        this.$refs['tableBody'].addEventListener('scroll', (e) => {
          if (e.target !== null && (!onScroll || onScroll === 'tableBody')) {
            clearTimeout(timer)
            onScroll = 'tableBody'
            this.$refs['tableHead'].scrollLeft = e.target.scrollLeft
            this.$refs['sticky_scroll_x'].scrollLeft = e.target.scrollLeft
            timer = setTimeout(() => {
              onScroll = false
            }, 500)
          }
        })
        // 底部粘性横行滚动条同步
        this.$refs['sticky_scroll_x'].addEventListener('scroll', (e) => {
          if (e.target !== null && (!onScroll || onScroll === 'sticky_scroll_x')) {
            clearTimeout(timer)
            onScroll = 'sticky_scroll_x'
            this.$refs['tableHead'].scrollLeft = e.target.scrollLeft
            this.$refs['tableBody'].scrollLeft = e.target.scrollLeft
            timer = setTimeout(() => {
              onScroll = false
            }, 500)
          }
        })
      })
    },
    dataChanged(val, dataIndex, rowIndex) {
      if (this.tableData[rowIndex]) {
        this.tableData[rowIndex][dataIndex] = val
        // 记录编辑的位置
        if (this.changedCell[dataIndex]) {
          this.changedCell[dataIndex].push(rowIndex)
        } else {
          this.changedCell[dataIndex] = [ rowIndex ]
        }
        this.$emit('change', JSON.parse(JSON.stringify(this.tableData[rowIndex])), dataIndex, rowIndex)
      }
      console.log('data change')
      this.cellStatus = 'readonly'
    },
    // 选中单元格
    selectCell({dataIndex, rowIndex}) {
      this.isMousedown = true
      this.rect = this.getCellInfo(dataIndex, rowIndex)
      this.addKeyListener()
    },
    cell2Edit(e) {
      const { rect } = this
      const col = this.columnFields[this.colDataIndexFields.indexOf(rect.dataIndex)]
      if (col.render) return // 自定义渲染阻止该事件
      if (!col.editConfig || (this.cellEditDisabled && this.cellEditDisabled(rect.dataIndex, rect.rowIndex, this.value))) {
        e && this.shaky(e)
      } else {
        this.cellStatus = 'edit'
      }
    },
    cellDblClick({ event }) {
      this.cell2Edit(event)
    },
    cellClick(dataIndex, rowIndex) {
      this.$emit('cellClick', dataIndex, rowIndex)
    },
    hiddenCellRect() {
      this.rect = {
        dataIndex: '',
        rowIndex: -1,
        isFixed: false,
        x: 0,
        y: 0,
        w: 0,
        h: 0,
        wrapW: 0
      }
      this.removeKeyListener()
    },
    cellMouseenter(e) {
      if (e.target !== null) {
        // console.log(e.target)
      }
    },
    cellMouseup() {
      this.isMousedown = false
    },
    setSelectDisabled(selectDisabled) { // 禁用选择
      if (selectDisabled) { // 禁用选中事件
        this.$el.addEventListener('dblclick', this.stopImmediatePropagation, true)
        this.$el.addEventListener('mousedown', this.stopImmediatePropagation, true)
      } else {
        this.$el.removeEventListener('dblclick', this.stopImmediatePropagation, true)
        this.$el.removeEventListener('mousedown', this.stopImmediatePropagation, true)
      }
    },
    shaky(e) { // 使元素抖动，禁止编辑时
      e.classList.add('shaky')
      setTimeout(() => {
        e.classList.remove('shaky')
      }, 300)
    },
    stopImmediatePropagation(e) {
      e.stopImmediatePropagation()
    },
    gridBlur() { // grid失去焦点
      // 避免打断正在执行到方法
      this.$nextTick(() => {
        this.hiddenCellRect()
      })
    }
  }
}
</script>
<style lang="scss">
@import './index.scss';
.dh_grid {
  position: relative;
  align-self: flex-start;
  border-top: 1px solid $border-color;
  .dh_grid_sticky_head {
    position: absolute;
    z-index: 200;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    pointer-events: none;
    .dh_grid_table {
      position: sticky;
      top: 0;
      width: 100%;
      overflow: hidden;
      pointer-events: auto;
    }
  }
  .dh_grid_table {
    position: relative;
    display: block;
    width: 100%;
    margin: 0 4px 0 0;
    box-sizing: border-box;
    border-collapse: separate;
    border-spacing: 0;
    table-layout: auto;
    outline-width: 0;
    cursor: default;
    max-width: none;
    max-height: none;
    box-sizing: border-box;
    &.table {
      overflow-x: auto;
      // 隐藏table原生滚动条
      &::-webkit-scrollbar {
        height: 0;
      }
    }
    thead {
      tr {
        th:first-child::before {
          content: '';
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          display: block;
          width: 1px;
          border-left: 1px solid $border-color;
        }
      }
    }
    tbody {
      tr {
        // td:first-child::before {
        //   content: '';
        //   position: absolute;
        //   top: 0;
        //   bottom: 0;
        //   left: 0;
        //   display: block;
        //   width: 1px;
        //   border-left: 1px solid $border-color;
        // }
        // td.fixed_left::before {
        //   display: none;
        // }
        // .fixed_right {
        //   box-shadow: -3px 1px 3px -1px #ccc;
        // }
        // .fixed_left {
        //   box-shadow: 2px 1px 3px -1px #ccc;
        // }
      }
    }
  }
  .sticky_scroll_x {
    position: sticky;
    bottom: 0;
    z-index: 100;
    width: 100%;
    height: 20px;
    overflow-x: auto;
    .scroll_cont {
      display: block;
      height: 1px;
    }
  }
  .br_point {
    position: absolute;
    width: 10px;
    height: 10px;
    background-color: $theme-color;
    border: 2px solid #fff;
    cursor: crosshair;
  }
}
</style>