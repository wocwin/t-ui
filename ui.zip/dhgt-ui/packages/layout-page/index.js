import DhgtLayoutPage from './src/layout-page';

/* istanbul ignore next */
DhgtLayoutPage.install = function(Vue) {
  Vue.component(DhgtLayoutPage.name, DhgtLayoutPage);
};

export default DhgtLayoutPage;
