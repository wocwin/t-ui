import DhRangePicker from './src';

/* istanbul ignore next */
DhRangePicker.install = function(Vue) {
  Vue.component(DhRangePicker.name, DhRangePicker);
};

export default DhRangePicker;
