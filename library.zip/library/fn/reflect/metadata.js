require('../../modules/es7.reflect.metadata');
module.exports = require('../../modules/_core').Reflect.metadata;
